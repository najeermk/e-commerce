
<?php
include "header.php";

include "database.php";


 $sql = "select * from items";
$result = mysqli_query($con, $sql);

?>
 

<div class="container">
  
  <div class="row">
<?php  
while ($row = mysqli_fetch_array($result)) {

echo '
    <div class="col-sm">
      
      	<img src="../photos/'.$row["photo"].'" width="250px">
      	<p>CONVERSE</p>
      
    </div>';
}

?>

</div>
</div>

<?php

include "footer.php";
?>