<?php
session_start();
if ($_SESSION["id"]) {
    }
else{
    header("location:../login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<title>Shoes Online</title>
</head>
<body>

<div class="container">


	
<nav class="nav justify-content-center">
  <a class="nav-link active" href="index.php">Home</a>
  <a class="nav-link" href="additems.php">Add items</a>
  <a class="nav-link" href="logout.php">Logout</a>
  <a class="nav-link" href="#">View Users</a>
</nav>
</div>
<div>
	<br>
</div>



