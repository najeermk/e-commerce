<?php
include "header.php";
?>

<div class="container">
	<h1>LOGIN</h1>
	<br>
<form method="POST" >
	
  <div class="row">
    
    <div class="col">
      <input type="email" class="form-control" name="email" placeholder="email">
       </div>
      <div class="col">
      <input type="password" class="form-control" name="pass" placeholder="password">
   
    </div>
  </div>
  <br>
      <button type="submit" name="submit" class="btn btn-primary">Login</button>

 
</form>
</div>

<?php

include "database.php";

if (isset($_POST["submit"])) {
    $email = $_POST["email"];
    $pass = $_POST["pass"];
     $sql= "select * from login where email='$email' and password='$pass'";
    echo $sql;
    $result=mysqli_query($con, $sql);
    if ($row=mysqli_fetch_array($result)) {
        $usertype= $row["usertype"];
        $_SESSION["id"]=$row["id"];
        echo $_SESSION["id"];
        $_SESSION["email"]=$email;
        if ($usertype== "admin") {
            header("location:admin/index.php");
        }
        if ($usertype=="user") {
            header("location:user/index.php");
        }
    }
    else{
        echo "invalid email or password";
    }

    }

include "footer.php";
?>