<?php
include "header.php";


include "database.php";
?>
<div class="container">
<table width="100%">
    <tr>
        <th>item id</th>
        <th>name</th>
        <th>price</th>
        <th>quantity</th>
    </tr>
 <?php   

 $sql="select * from cart where userid=$userid";
    $result = mysqli_query($con, $sql);

    while ($row = mysqli_fetch_array($result)) {

        echo  "<tr><td>" . $row["itemid"];
        echo  "</td><td>" . $row["name"];
        echo  "</td><td>" . $row["price"];
        echo  "</td><td>" . $row["quantity"];
        echo "</td><td><img src='../photos/".$row["photo"]."' width=100px>";
        echo "</td></tr>";
        
    }
include "footer.php";
    ?>

