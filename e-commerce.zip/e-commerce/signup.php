<?php
include "header.php";
?>

<div class="container">
	<h1>SIGN UP</h1>
	<br>
<form method="POST" action="#">
	
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" name="name" placeholder="name">
    </div>
    <div class="col">
      <input type="email" class="form-control" name="email" placeholder="email">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col">
      <input type="password" class="form-control" name="pass" placeholder="password">
    </div>
    <div class="col">
      <input type="text" class="form-control" name="phone" placeholder="phone">
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-lg">
      <textarea rows=4 class="form-control" name="address" placeholder="address"></textarea> 
    </div>
    
  </div>
  <br>
  		<input value="sign up" type="submit" name="submit" class="btn btn-primary" > 
 
</form>
</div>

<?php

include "database.php";

if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $pass=$_POST["pass"];
    $phoneno = $_POST["phone"];
    $address = $_POST["address"];
   
    $sql= "insert into login (email,password,usertype) values('$email','$pass','user')";
   
    $result = mysqli_query($con, $sql);
    // $id="";
    // $sql= "select max(id) as id from login";
    // $result = mysqli_query($con, $sql);
    // if($row =mysqli_fetch_array($result)){
    //     $id=$row[0];
    // }
    $sql = "insert into signup (name,email,phone,address) values('$name','$email','$phoneno','$address')";
   
    $result = mysqli_query($con, $sql);
    
}

include "footer.php";
?>