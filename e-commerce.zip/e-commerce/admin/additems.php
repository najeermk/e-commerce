<?php
include "header.php";
?>

<div class="container">
	<h1>Add items</h1>
	<br>
<form method="POST" enctype="multipart/form-data">
	
  <div class="row">
    <div class="col">
      <input type="text" class="form-control" name="name" placeholder="name">
    </div>
    <div class="col">
      <input type="text" class="form-control" name="price" placeholder="price">
    </div>
  </div>
 
  <div class="row">
    <div class="col">
      <input type="file" class="form-control" name="photo" placeholder="photo">
    </div>
      
  </div>
  <br>
  		<input value="Add" type="submit" name="submit" class="btn btn-primary" > 
 
</form>
</div>

<?php

include "database.php";

if (isset($_POST["submit"])) {
    $name = $_POST["name"];
    $price = $_POST["price"];
       
    $filename = $_FILES["photo"]["name"];
    $file_loc = $_FILES["photo"]["tmp_name"];
    move_uploaded_file($file_loc, "../photos/" . $filename);
    
    $sql = "insert into items (name,price,photo) values('$name','$price','$filename')";
   
    $result = mysqli_query($con, $sql);
    
}

include "footer.php";
?>