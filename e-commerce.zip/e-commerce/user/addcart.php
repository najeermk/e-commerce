<?php
include "header.php";


include "database.php";

$id = $_GET["id"];
$sql = "select * from items where id=$id";

$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
?>
<div class="container">

    <form method="POST">
        <input readonly type="hidden" name="id" value='<?php echo $row["id"]; ?>'>
        <input readonly type="text" name="name" value='<?php echo $row["name"]; ?>'>
        <input readonly type="text" name="price" value='<?php echo $row["price"]; ?>'>
        <img name="photo" width="100px" src='../photos/<?php echo $row["photo"]; ?>'>

        <input type="number" name="quantity" placeholder="quantity">

        <input type="submit" name="add" value="Add to Cart">
    </form>
</div>


<div class="container">
<table width="100%">
    <tr>
        <th>item id</th>
        <th>name</th>
        <th>price</th>
        <th>quantity</th>
    </tr>

<?php
}
if(isset($_POST["add"])){
	$userid=$_SESSION["id"];
	$itemid=$_POST["id"];
	$name=$_POST["name"];
	$price=$_POST["price"];
	$quantity=$_POST["quantity"];
	$sql="insert into cart (name,price,quantity,userid,itemid) values ('$name','$price','$quantity','$userid','$itemid')";
	$result = mysqli_query($con, $sql);
    $sql="select * from cart where userid=$userid";
    $result = mysqli_query($con, $sql);

    while ($row = mysqli_fetch_array($result)) {

        echo  "<tr><td>" . $row["itemid"];
        echo  "</td><td>" . $row["name"];
        echo  "</td><td>" . $row["price"];
        echo  "</td><td>" . $row["quantity"];
        //echo "</td><td><img src='../photos/".$row["photo"]."' width=100px>";
        echo "</td></tr>";
        
    }

}
?>
</table>
</div>

<?php

include "footer.php";
?>